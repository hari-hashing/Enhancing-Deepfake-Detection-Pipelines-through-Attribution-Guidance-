import os

import torch
import torch.nn.functional as F
from flask import Flask, render_template, request, redirect, url_for
from werkzeug.utils import secure_filename
from torchvision import transforms
from PIL import Image
import numpy as np
import cv2

# Grad-CAM imports
from pytorch_grad_cam import GradCAM
from pytorch_grad_cam.utils.image import show_cam_on_image

# import your modules
from models.fake_image_model import build_model
from utils.augmentations import get_val_transforms

# Flask setup
app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = "static/uploads"
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

# Load model
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model = build_model().to(device)
checkpoint_path = "checkpoints/best_model.pth"   # <-- change to your checkpoint
model.load_state_dict(torch.load(checkpoint_path, map_location=device))
model.eval()

# transforms (same as validation)
transform = get_val_transforms()
CLASSES = ["Real", "Fake"]

# pick the last convolutional layer for Grad-CAM

target_layer = model.base_model.features[-2].conv[1][0]
print(target_layer)
def predict_image(image_path):
    print("image_path:",image_path)
    image = Image.open(image_path).convert("RGB")
#    image=np.array(image)
    tensor = transform(image).unsqueeze(0).to(device)

    # normalize for CAM visualization
    rgb_img = np.array(image.resize((224, 224))).astype(np.float32) / 255.0
    print("tensor_shape:",rgb_img.shape)
    #with torch.no_grad(): #gradients are required for computing GRAD-CAM
    output = model(tensor)
    print("output:",output)
    probs = F.softmax(output, dim=1)[0].detach().cpu().numpy()
    pred_idx = np.argmax(probs)
    confidence = probs[pred_idx]
    print("prob:",confidence)
    # Grad-CAM
    cam = GradCAM(model=model, target_layers=[target_layer])
    grayscale_cam = cam(input_tensor=tensor, targets=None)[0, :]
    print("grayscale_cam:",grayscale_cam)
    cam_image = show_cam_on_image(rgb_img, grayscale_cam, use_rgb=True,image_weight=0.6)

    # save heatmap
    heatmap_path = os.path.join(app.config["UPLOAD_FOLDER"], "heatmap_" + os.path.basename(image_path))
    cv2.imwrite(heatmap_path, cv2.cvtColor(cam_image, cv2.COLOR_RGB2BGR))

    return CLASSES[pred_idx], confidence, heatmap_path


@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        if "file" not in request.files:
            return redirect(request.url)
        file = request.files["file"]
        if file.filename == "":
            return redirect(request.url)

        if file:
            filename = secure_filename(file.filename)
            filepath = os.path.join(app.config["UPLOAD_FOLDER"], filename)
            file.save(filepath)

            label, confidence, heatmap_path = predict_image(filepath)
            return render_template("result.html",
                                   filename=filename,
                                   label=label,
                                   confidence=confidence,
                                   heatmap=os.path.basename(heatmap_path))
    return render_template("index.html")


@app.route("/uploads/<filename>")
def uploaded_file(filename):
    return url_for("static", filename=f"uploads/{filename}")


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=8080,debug=True)

